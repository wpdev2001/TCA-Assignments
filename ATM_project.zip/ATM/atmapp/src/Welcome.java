import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.applet.*;

import static com.font.black;

public class Welcome extends JFrame implements ActionListener
{
    JFrame jf;
    Font f,f1;
	JButton b,b1;
	JLabel l1,l2,l3,l4,l5,l6;
	ImageIcon img1;
	JTextField t1;
	String strdate,strtime;
	//File wavFile = new File("clicksound.au");
    //AudioClip sound;

	public Welcome()
	{
		jf=new JFrame();
		f = new Font("Times New Roman",Font.BOLD,20);//button
		f1 = new Font("Times New Roman",Font.BOLD,25);//label
		jf.setLayout(null);
		//ImageIcon med  = new ImageIcon("src/bank.png");

		//Image med1 = med.getImage();

		//Image med2 = med1.getScaledInstance(100,100,Image.SCALE_SMOOTH);

		//ImageIcon meds = new ImageIcon(med2);
		//JLabel imagelable = new JLabel();
		//imagelable.setIcon(meds);
		//imagelable.setLocation(300,500);
		//JLabel l1 = new JLabel(meds);
		//l1.setLayout(new GridLayout(1,1,2,2));
		//jf.add(imagelable);


		//try{sound = Applet.newAudioClip(wavFile.toURL());}
        //catch(Exception e){e.printStackTrace();}

	    l2=new JLabel("Welcome To PUNE CITY BANK");
		l2.setFont(new Font("Times New Roman",Font.BOLD,35));
		l2.setForeground(black);
		l2.setBounds(140,230,500,30);
		jf.add(l2);

		l3=new JLabel("ATM Services");
		l3.setFont(new Font("Times New Roman",Font.BOLD,30));
		l3.setForeground(black);
		l3.setBounds(300,300,300,30);
		jf.add(l3);

		l4=new JLabel("Press OK To Use ATM Service or Press Exit to quite");
		l4.setFont(f1);
		l4.setForeground(black);
		l4.setBounds(120,370,580,30);
		jf.add(l4);

		b=new JButton("OK",new ImageIcon("ok.png"));
		b.setFont(f);
	 	b.setBounds(200,550,130,40);
		jf.add(b);
		b.addActionListener(this);

		b1=new JButton("Exit",new ImageIcon("cancel.png"));
		b1.setFont(f);
		b1.setBounds(500,550,130,40);
		jf.add(b1);
		b1.addActionListener(this);

        //img1=new ImageIcon("src/bank.png");
		//Image med1 = img1.getImage();
		//Image med2 = med1.getScaledInstance(400,400,Image.SCALE_SMOOTH);

		//l1=new JLabel(img1);
		//l1.setBounds(250,250,500,500);
        //jf.add(l1);

		 jf.setTitle("WELCOME TO PUNE CITY BANK ATM");
	     jf.setSize(800,800);
		 jf.setLocation(220,200);
		 jf.setForeground(black);
		 jf.setResizable(false);
	     jf.setVisible(true);

	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b)
		{
			//sound.play();
	       	new Atmcardno();
            jf.setVisible(false);
		}
		else if(ae.getSource()==b1)
		{
			//sound.play();
			System.exit(0);
		}
    }
	public static void main(String args[])
	{
		new Welcome();
	}

}