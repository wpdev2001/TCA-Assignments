package com;

import java.awt.*;

public class font {

    public static java.awt.Color b = new java.awt.Color(0,0,255);
    public static java.awt.Color black = new java.awt.Color(0,0,0);
}
