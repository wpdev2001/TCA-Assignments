/**
 * @(#)atmapp.java
 *
 * atmapp application
 *
 * @author 
 * @version 1.00 2014/4/19
 */
 
public class atmapp {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}
